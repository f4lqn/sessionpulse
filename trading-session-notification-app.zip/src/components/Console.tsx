import { FlaskConical, Hourglass, MoonStar } from 'lucide-react';
import type { SoundKind } from '../lib/sound';
import { cn } from '../utils/cn';
import { Switch } from './ui';

export interface FeedItem {
  id: number;
  sessionId: string | null;
  color: string;
  title: string;
  body: string;
  ts: number;
  kind: 'open' | 'close' | 'test' | 'info';
}

interface Props {
  leadMin: number;
  onLead: (v: number) => void;
  soundKind: SoundKind;
  onSoundKind: (v: SoundKind) => void;
  closeAlert: boolean;
  onCloseAlert: (v: boolean) => void;
  onTest: () => void;
  feed: FeedItem[];
  fmtWhen: (ts: number) => string;
}

const LEADS = [
  { v: 0, label: 'AT BELL' },
  { v: 1, label: '1 MIN' },
  { v: 5, label: '5 MIN' },
  { v: 15, label: '15 MIN' },
  { v: 30, label: '30 MIN' },
];

const SOUNDS: { v: SoundKind; label: string }[] = [
  { v: 'chime', label: 'Glass Chime' },
  { v: 'pulse', label: 'Radar Pulse' },
  { v: 'bell', label: 'Desk Bell' },
];

export default function Console({ leadMin, onLead, soundKind, onSoundKind, closeAlert, onCloseAlert, onTest, feed, fmtWhen }: Props) {
  return (
    <div className="grid gap-5 lg:grid-cols-[380px_1fr]">
      {/* ── alert console ── */}
      <section className="anim-fade-up rounded-3xl border border-white/[0.07] bg-white/[0.02] p-5 sm:p-6" style={{ animationDelay: '150ms' }}>
        <div className="mb-6 flex items-baseline gap-3">
          <span className="font-mono text-[11px] font-semibold tracking-[0.25em] text-emerald-400/80">04</span>
          <h2 className="text-sm font-semibold uppercase tracking-[0.22em] text-slate-300">Alert console</h2>
        </div>

        <div className="space-y-6">
          <div>
            <div className="mb-2.5 flex items-center gap-2 font-mono text-[10px] tracking-[0.25em] text-slate-500">
              <Hourglass size={11} className="text-cyan-300" /> RING BEFORE OPEN
            </div>
            <div className="flex rounded-2xl border border-white/[0.08] bg-[#080b11] p-1">
              {LEADS.map((l) => (
                <button
                  key={l.v}
                  onClick={() => onLead(l.v)}
                  className={cn(
                    'flex-1 rounded-xl px-1 py-2 font-mono text-[10px] font-bold tracking-wider text-slate-500 transition-all duration-200 active:scale-95',
                    leadMin === l.v && 'seg-active',
                  )}
                >
                  {l.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <div className="mb-2.5 font-mono text-[10px] tracking-[0.25em] text-slate-500">ALERT SOUND</div>
            <div className="space-y-1.5">
              {SOUNDS.map((s) => (
                <button
                  key={s.v}
                  onClick={() => onSoundKind(s.v)}
                  className={cn(
                    'flex w-full items-center justify-between rounded-xl border px-3.5 py-2.5 transition-all duration-200 active:scale-[0.99]',
                    soundKind === s.v
                      ? 'border-emerald-400/30 bg-emerald-400/[0.08]'
                      : 'border-white/[0.07] bg-white/[0.02] hover:bg-white/[0.045]',
                  )}
                >
                  <span className={cn('text-[13px] font-semibold', soundKind === s.v ? 'text-emerald-200' : 'text-slate-400')}>{s.label}</span>
                  <span className={cn('h-2 w-2 rounded-full transition-all', soundKind === s.v ? 'bg-emerald-400 shadow-[0_0_10px_rgba(63,224,168,0.9)]' : 'bg-white/15')} />
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between rounded-2xl border border-white/[0.08] bg-white/[0.02] px-4 py-3">
            <div className="flex items-center gap-2.5">
              <MoonStar size={14} className="text-violet-300" />
              <div className="leading-tight">
                <div className="text-[13px] font-semibold text-slate-200">Closing bell</div>
                <div className="font-mono text-[9px] tracking-widest text-slate-500">PING 15 MIN BEFORE CLOSE</div>
              </div>
            </div>
            <Switch on={closeAlert} onChange={onCloseAlert} accent="#a78bfa" />
          </div>

          <button
            onClick={onTest}
            className="group flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-cyan-400/90 to-emerald-400/90 px-4 py-3 text-[13px] font-bold text-[#041210] transition-all hover:shadow-[0_0_32px_rgba(56,224,200,0.35)] active:scale-[0.98]"
          >
            <FlaskConical size={15} className="transition-transform group-hover:-rotate-12" />
            Fire test alert
          </button>
        </div>
      </section>

      {/* ── signal log ── */}
      <section className="anim-fade-up flex flex-col rounded-3xl border border-white/[0.07] bg-white/[0.02] p-5 sm:p-6" style={{ animationDelay: '220ms' }}>
        <div className="mb-5 flex items-center justify-between">
          <div className="flex items-baseline gap-3">
            <span className="font-mono text-[11px] font-semibold tracking-[0.25em] text-emerald-400/80">05</span>
            <h2 className="text-sm font-semibold uppercase tracking-[0.22em] text-slate-300">Signal log</h2>
          </div>
          <span className="flex items-center gap-1.5 font-mono text-[9px] tracking-[0.25em] text-slate-500">
            <span className="live-dot h-1.5 w-1.5 rounded-full bg-emerald-400" /> MONITORING
          </span>
        </div>

        {feed.length === 0 ? (
          <div className="grid flex-1 place-items-center rounded-2xl border border-dashed border-white/[0.09] px-6 py-12 text-center">
            <div>
              <p className="font-mono text-[11px] tracking-[0.25em] text-slate-500">NO SIGNALS YET</p>
              <p className="mx-auto mt-3 max-w-xs text-[13px] leading-relaxed text-slate-500">
                Keep this tab open — SessionPulse rings here, as a browser notification, and with sound the moment a session opens.
              </p>
            </div>
          </div>
        ) : (
          <div className="max-h-[340px] space-y-2 overflow-y-auto pr-1">
            {feed.map((f) => (
              <div
                key={f.id}
                className="anim-toast flex items-start gap-3 rounded-2xl border border-white/[0.06] bg-[#080b11] px-4 py-3"
              >
                <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full" style={{ background: f.color, boxShadow: `0 0 10px ${f.color}` }} />
                <div className="min-w-0 flex-1">
                  <div className="flex items-baseline justify-between gap-3">
                    <span className="truncate text-[13px] font-bold text-slate-100">{f.title}</span>
                    <span className="shrink-0 font-mono text-[10px] tabular text-slate-500">{fmtWhen(f.ts)}</span>
                  </div>
                  <p className="mt-0.5 truncate text-[12px] text-slate-400">{f.body}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
