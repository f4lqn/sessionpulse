import { BellRing, BellOff, Globe2, Radar, Volume2, VolumeX, MonitorSmartphone } from 'lucide-react';
import { Dropdown } from './ui';
import { TZ_OPTIONS, offsetLabel, deviceOffset } from '../lib/time';

export type NotifPerm = 'default' | 'granted' | 'denied' | 'unsupported';

interface Props {
  perm: NotifPerm;
  onRequestPerm: () => void;
  offsetMin: number;
  onOffset: (v: number) => void;
  soundOn: boolean;
  onSound: (v: boolean) => void;
  now: number;
}

export default function Header({ perm, onRequestPerm, offsetMin, onOffset, soundOn, onSound }: Props) {
  return (
    <header className="sticky top-0 z-40 border-b border-white/[0.06] bg-[#06080c]/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-[1400px] items-center justify-between gap-3 px-4 sm:px-6">
        {/* brand */}
        <div className="flex items-center gap-3">
          <div className="relative grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-emerald-400/25 to-cyan-400/10 shadow-[inset_0_0_0_1px_rgba(63,224,168,0.35)]">
            <Radar size={17} className="text-emerald-300" />
            <span className="live-dot absolute -top-0.5 -right-0.5 h-2 w-2 rounded-full bg-emerald-400" />
          </div>
          <div className="leading-none">
            <div className="text-[15px] font-bold tracking-[0.14em] text-white">
              SESSION<span className="text-emerald-400">PULSE</span>
            </div>
            <div className="mt-1 font-mono text-[9px] tracking-[0.32em] text-slate-500">FX SESSION RADAR</div>
          </div>
        </div>

        {/* controls */}
        <div className="flex items-center gap-2">
          <Dropdown<number>
            value={offsetMin}
            onChange={onOffset}
            wide
            icon={<Globe2 size={14} className="text-cyan-300" />}
            options={[
              ...TZ_OPTIONS.map((t) => ({
                value: t.off,
                label: offsetLabel(t.off),
                sub: t.place,
              })),
            ]}
          />
          <button
            onClick={() => onOffset(deviceOffset())}
            title="Match my device timezone"
            className="hidden h-9 w-9 place-items-center rounded-full border border-white/10 bg-white/[0.04] text-slate-400 transition-all hover:border-white/20 hover:text-white active:scale-95 sm:grid"
          >
            <MonitorSmartphone size={15} />
          </button>
          <button
            onClick={() => onSound(!soundOn)}
            title={soundOn ? 'Mute alert sounds' : 'Unmute alert sounds'}
            className={`grid h-9 w-9 place-items-center rounded-full border transition-all active:scale-95 ${
              soundOn
                ? 'border-emerald-400/30 bg-emerald-400/10 text-emerald-300'
                : 'border-white/10 bg-white/[0.04] text-slate-500 hover:text-slate-300'
            }`}
          >
            {soundOn ? <Volume2 size={15} /> : <VolumeX size={15} />}
          </button>

          {perm !== 'granted' ? (
            <button
              onClick={onRequestPerm}
              className="group relative flex items-center gap-2 overflow-hidden rounded-full bg-gradient-to-r from-emerald-400 to-cyan-400 px-4 py-2 text-[13px] font-bold text-[#041210] transition-all hover:shadow-[0_0_28px_rgba(63,224,168,0.45)] active:scale-95"
            >
              {perm === 'denied' ? <BellOff size={14} /> : <BellRing size={14} className="transition-transform group-hover:rotate-12" />}
              <span className="hidden sm:inline">{perm === 'denied' ? 'Notifications blocked' : perm === 'unsupported' ? 'Enable alerts' : 'Enable notifications'}</span>
              <span className="sm:hidden">{perm === 'denied' ? 'Blocked' : 'Enable'}</span>
            </button>
          ) : (
            <div className="flex items-center gap-2 rounded-full border border-emerald-400/25 bg-emerald-400/[0.08] px-3.5 py-2">
              <BellRing size={13} className="text-emerald-300" />
              <span className="hidden text-[12px] font-semibold text-emerald-200 sm:inline">Alerts armed</span>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
