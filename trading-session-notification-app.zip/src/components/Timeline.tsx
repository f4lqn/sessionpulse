import { useMemo } from 'react';
import {
  SESSIONS, fmtClock, minutesIntoZonedDay, offsetLabel, sessionStateAt,
  wallToUtcMs, zonedDayStartMs, zonedParts, type SessionDef,
} from '../lib/time';
import { cn } from '../utils/cn';

interface Props { now: number; offsetMin: number; }

interface Seg { left: number; width: number; isOpenNow: boolean; }

function segmentsFor(sess: SessionDef, now: number, offMin: number): Seg[] {
  const dayStart = zonedDayStartMs(now, offMin);
  const dayEnd = dayStart + 24 * 3600_000;
  const segs: Seg[] = [];
  for (let k = -1; k <= 1; k++) {
    const probe = now + k * 86400_000;
    const p = zonedParts(probe, sess.tz);
    const dow = new Date(Date.UTC(p.y, p.mo, p.d)).getUTCDay();
    if (dow === 0 || dow === 6) continue;
    const o = wallToUtcMs(sess.tz, p.y, p.mo, p.d, Math.floor(sess.openMin / 60), sess.openMin % 60);
    const c = wallToUtcMs(sess.tz, p.y, p.mo, p.d, Math.floor(sess.closeMin / 60), sess.closeMin % 60);
    const L = Math.max(o, dayStart);
    const R = Math.min(c, dayEnd);
    if (R <= L) continue;
    segs.push({
      left: ((L - dayStart) / 86400_000) * 100,
      width: ((R - L) / 86400_000) * 100,
      isOpenNow: now >= o && now < c,
    });
  }
  return segs.sort((a, b) => a.left - b.left);
}

const HOURS = [0, 3, 6, 9, 12, 15, 18, 21, 24];

export default function Timeline({ now, offsetMin }: Props) {
  const rows = useMemo(
    () => SESSIONS.map((s) => ({ s, segs: segmentsFor(s, now, offsetMin), st: sessionStateAt(s, now) })),
    [Math.floor(now / 30000), offsetMin],
  );
  const needle = (minutesIntoZonedDay(now, offsetMin) / 1440) * 100;

  return (
    <section className="anim-fade-up rounded-3xl border border-white/[0.07] bg-gradient-to-b from-white/[0.035] to-transparent p-5 sm:p-7" style={{ animationDelay: '90ms' }}>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-baseline gap-3">
          <span className="font-mono text-[11px] font-semibold tracking-[0.25em] text-emerald-400/80">02</span>
          <h2 className="text-sm font-semibold uppercase tracking-[0.22em] text-slate-300">Session map · 24h</h2>
        </div>
        <span className="font-mono text-[11px] tracking-widest text-slate-500">RENDERED IN {offsetLabel(offsetMin)} · DST-AWARE</span>
      </div>

      <div className="grid grid-cols-[86px_1fr] gap-x-3 sm:grid-cols-[120px_1fr]">
        {/* ruler */}
        <div />
        <div className="relative mb-2 h-4">
          {HOURS.map((h) => (
            <span
              key={h}
              className="absolute -translate-x-1/2 font-mono text-[9px] tracking-widest text-slate-500"
              style={{ left: `${(h / 24) * 100}%`, transform: h === 0 ? 'none' : h === 24 ? 'translateX(-100%)' : 'translateX(-50%)' }}
            >
              {String(h).padStart(2, '0')}
            </span>
          ))}
        </div>

        {/* rows */}
        {rows.map(({ s, segs, st }) => (
          <Row key={s.id} label={
            <div className="flex items-center gap-2 py-1">
              <span
                className="grid h-7 w-9 place-items-center rounded-md font-mono text-[9px] font-bold tracking-wider"
                style={{ background: s.dim, color: s.color, boxShadow: `inset 0 0 0 1px ${s.color}33` }}
              >
                {s.code}
              </span>
              <div className="hidden leading-tight sm:block">
                <div className="text-[11px] font-semibold text-slate-300">{s.city}</div>
                <div className="font-mono text-[8px] tracking-[0.2em] text-slate-600">{s.region.toUpperCase()}</div>
              </div>
            </div>
          }>
            {/* alternating 6h bands */}
            {[0, 1, 2, 3].map((i) => (
              <div key={i} className={cn('absolute inset-y-0', i % 2 === 0 && 'bg-white/[0.018]')} style={{ left: `${i * 25}%`, width: '25%' }} />
            ))}
            {/* hour ticks */}
            {Array.from({ length: 25 }, (_, i) => (
              <div
                key={i}
                className="absolute inset-y-0 w-px bg-white/[0.06]"
                style={{ left: `${(i / 24) * 100}%`, opacity: i % 3 === 0 ? 1 : 0.35 }}
              />
            ))}

            {/* session segments */}
            {segs.map((g, i) => (
              <div
                key={i}
                className="absolute inset-y-[5px] rounded-[4px] mix-blend-screen"
                style={{
                  left: `${g.left}%`,
                  width: `max(${g.width}%, 3px)`,
                  background: `linear-gradient(180deg, ${s.color}e6, ${s.color}66)`,
                  boxShadow: g.isOpenNow
                    ? `0 0 18px ${s.color}90, inset 0 0 0 1px ${s.color}`
                    : `inset 0 0 0 1px ${s.color}55`,
                  opacity: g.isOpenNow ? 1 : 0.42,
                }}
              />
            ))}

            {segs.length === 0 && (
              <span className="absolute left-2 top-1/2 -translate-y-1/2 font-mono text-[8px] tracking-[0.25em] text-slate-600">WEEKEND</span>
            )}

            <span className={cn(
              'absolute -right-1 top-1/2 hidden -translate-y-1/2 translate-x-full pl-2 font-mono text-[8px] tracking-[0.25em] xl:block',
              st.isOpen ? 'font-bold' : 'text-slate-600',
            )} style={st.isOpen ? { color: s.color } : undefined}>
              {st.isOpen ? '● LIVE' : 'CLOSED'}
            </span>
          </Row>
        ))}

        {/* needle overlay — spans all 4 rows */}
        <div />
        <div className="pointer-events-none relative -mt-[184px] h-[184px]">
          <div className="scanline absolute top-0 h-full w-16 bg-gradient-to-r from-transparent via-emerald-300/[0.06] to-transparent" />
          <div className="absolute -top-1 bottom-0 transition-[left] duration-1000 ease-linear" style={{ left: `${needle}%` }}>
            <div className="absolute -left-px top-3 bottom-1 w-[2px] bg-gradient-to-b from-emerald-300 via-emerald-300/70 to-transparent shadow-[0_0_14px_rgba(63,224,168,0.8)]" />
            <div className="absolute -left-[5px] top-[9px] h-[10px] w-[10px] rotate-45 border border-emerald-300 bg-[#06080c] shadow-[0_0_10px_rgba(63,224,168,0.9)]" />
            <div className="absolute left-2 top-0 rounded-md border border-emerald-300/30 bg-[#0a1210] px-1.5 py-0.5 font-mono text-[9px] font-bold tabular text-emerald-300">
              {fmtClock(now, offsetMin, false)}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Row({ label, children }: { label: React.ReactNode; children: React.ReactNode }) {
  return (
    <>
      <div className="flex items-center">{label}</div>
      <div className="relative my-1.5 h-[34px] overflow-hidden rounded-lg border border-white/[0.05] bg-[#080b11]">
        {children}
      </div>
    </>
  );
}
