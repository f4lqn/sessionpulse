import { useEffect, useRef, useState, type ReactNode } from 'react';
import { Check, ChevronDown } from 'lucide-react';
import { cn } from '../utils/cn';

export interface DropOption<T> {
  value: T;
  label: string;
  sub?: string;
}

interface DropdownProps<T> {
  value: T;
  options: DropOption<T>[];
  onChange: (v: T) => void;
  icon?: ReactNode;
  className?: string;
  panelClass?: string;
  wide?: boolean;
}

export function Dropdown<T extends string | number>({ value, options, onChange, icon, className, panelClass, wide }: DropdownProps<T>) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const close = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    const esc = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    document.addEventListener('mousedown', close);
    document.addEventListener('keydown', esc);
    return () => {
      document.removeEventListener('mousedown', close);
      document.removeEventListener('keydown', esc);
    };
  }, []);

  const selected = options.find((o) => o.value === value);

  return (
    <div ref={ref} className={cn('relative', className)}>
      <button
        onClick={() => setOpen((o) => !o)}
        className={cn(
          'group flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-3.5 py-2',
          'text-[13px] font-medium text-slate-200 transition-all duration-300',
          'hover:border-white/20 hover:bg-white/[0.07] active:scale-[0.97]',
          open && 'border-white/25 bg-white/[0.08]',
        )}
      >
        {icon}
        <span className="font-mono tabular tracking-tight">{selected?.label}</span>
        <ChevronDown size={14} className={cn('text-slate-500 transition-transform duration-300', open && 'rotate-180 text-slate-300')} />
      </button>

      {open && (
        <div
          className={cn(
            'drop-panel absolute right-0 z-50 mt-2 max-h-80 overflow-y-auto rounded-2xl p-1.5 anim-toast',
            wide ? 'w-72' : 'w-56',
            panelClass,
          )}
        >
          {options.map((o) => {
            const active = o.value === value;
            return (
              <button
                key={String(o.value)}
                onClick={() => { onChange(o.value); setOpen(false); }}
                className={cn(
                  'flex w-full items-center justify-between gap-3 rounded-xl px-3 py-2 text-left transition-colors duration-150',
                  active ? 'bg-white/[0.08]' : 'hover:bg-white/[0.05]',
                )}
              >
                <span className="min-w-0">
                  <span className={cn('block font-mono text-[13px] tabular', active ? 'text-white' : 'text-slate-300')}>{o.label}</span>
                  {o.sub && <span className="block truncate text-[11px] text-slate-500">{o.sub}</span>}
                </span>
                {active && <Check size={14} className="shrink-0 text-emerald-400" />}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ── Toggle switch ───────────────────────────────── */
export function Switch({ on, onChange, accent = '#3FE0A8' }: { on: boolean; onChange: (v: boolean) => void; accent?: string }) {
  return (
    <button
      onClick={() => onChange(!on)}
      aria-pressed={on}
      className={cn(
        'relative h-[22px] w-[40px] shrink-0 rounded-full border transition-all duration-300 active:scale-95',
        on ? 'border-transparent' : 'border-white/15 bg-white/[0.06]',
      )}
      style={on ? { background: `${accent}2e`, boxShadow: `inset 0 0 0 1px ${accent}55` } : undefined}
    >
      <span
        className="absolute top-1/2 h-[14px] w-[14px] -translate-y-1/2 rounded-full transition-all duration-300"
        style={{
          left: on ? 'calc(100% - 18px)' : '4px',
          background: on ? accent : 'rgba(255,255,255,0.35)',
          boxShadow: on ? `0 0 10px ${accent}aa` : 'none',
        }}
      />
    </button>
  );
}

/* ── Section label ───────────────────────────────── */
export function SectionTag({ index, title, right }: { index: string; title: string; right?: ReactNode }) {
  return (
    <div className="mb-5 flex items-end justify-between gap-4">
      <div className="flex items-baseline gap-3">
        <span className="font-mono text-[11px] font-semibold tracking-[0.25em] text-emerald-400/80">{index}</span>
        <h2 className="text-sm font-semibold tracking-[0.22em] text-slate-300 uppercase">{title}</h2>
      </div>
      {right && <div className="flex items-center gap-2">{right}</div>}
    </div>
  );
}
