import { SESSIONS, fmtClock, fmtDate, fmtInZone, gmtLabel, offsetLabel, sessionStateAt } from '../lib/time';
import { cn } from '../utils/cn';

interface Props {
  now: number;
  offsetMin: number;
}

export default function MasterClock({ now, offsetMin }: Props) {
  const clock = fmtClock(now, offsetMin);
  const [hh, mm, ss] = clock.split(':');
  const states = SESSIONS.map((s) => ({ s, st: sessionStateAt(s, now) }));
  const openNow = states.filter((x) => x.st.isOpen);
  const next = states
    .filter((x) => !x.st.isOpen)
    .sort((a, b) => a.st.nextOpen - b.st.nextOpen)[0];

  return (
    <section className="anim-fade-up relative overflow-hidden rounded-3xl border border-white/[0.07] bg-gradient-to-b from-white/[0.045] to-white/[0.015] p-6 sm:p-10">
      {/* inner glow */}
      <div className="pointer-events-none absolute -top-40 left-1/2 h-80 w-[42rem] -translate-x-1/2 rounded-full bg-emerald-400/[0.07] blur-[110px]" />

      <div className="relative grid items-end gap-8 lg:grid-cols-[1fr_auto]">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <span className="rounded-full border border-white/10 bg-white/[0.05] px-3 py-1 font-mono text-[11px] font-semibold tracking-widest text-cyan-200">
              {offsetLabel(offsetMin)}
            </span>
            <span className="font-mono text-[11px] tracking-[0.28em] text-slate-500">{fmtDate(now, offsetMin)}</span>
          </div>

          {/* the clock */}
          <div className="mt-4 font-mono font-extrabold leading-[0.9] tracking-[-0.04em] text-white tabular">
            <span className="text-[clamp(64px,11vw,148px)]">{hh}</span>
            <span className="colon text-[clamp(64px,11vw,148px)] text-emerald-300/90">:</span>
            <span className="text-[clamp(64px,11vw,148px)]">{mm}</span>
            <span className="ml-3 text-[clamp(24px,3.4vw,44px)] font-bold text-slate-500">{ss}</span>
          </div>

          {/* now-trading strip */}
          <div className="mt-5 flex flex-wrap items-center gap-2">
            <span className="font-mono text-[10px] tracking-[0.3em] text-slate-500">ON DESK NOW</span>
            {openNow.length > 0 ? (
              openNow.map(({ s }) => (
                <span
                  key={s.id}
                  className="flex items-center gap-1.5 rounded-full px-3 py-1 text-[12px] font-semibold"
                  style={{ background: s.dim, color: s.color, boxShadow: `inset 0 0 0 1px ${s.color}44` }}
                >
                  <span className="ping-dot h-1.5 w-1.5 rounded-full" style={{ background: s.color, ['--pc' as any]: `${s.color}66` }} />
                  {s.city}
                </span>
              ))
            ) : (
              <span className="rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-[12px] font-medium text-slate-400">
                All desks dark — next up: {next.s.city}
              </span>
            )}
          </div>
        </div>

        {/* desk readouts */}
        <div className="grid min-w-[300px] grid-cols-2 gap-px overflow-hidden rounded-2xl border border-white/[0.07] bg-white/[0.05] sm:grid-cols-2 lg:grid-cols-1">
          {states.map(({ s, st }) => (
            <div key={s.id} className="flex items-center justify-between gap-6 bg-[#0a0e15]/90 px-4 py-3">
              <div className="flex items-center gap-2.5">
                <span
                  className={cn('h-1.5 w-1.5 rounded-full', st.isOpen && 'ping-dot')}
                  style={{ background: st.isOpen ? s.color : 'rgba(255,255,255,0.2)', ['--pc' as any]: `${s.color}66` }}
                />
                <div className="leading-tight">
                  <div className="text-[12px] font-semibold text-slate-200">{s.city}</div>
                  <div className="font-mono text-[9px] tracking-widest text-slate-500">{gmtLabel(now, s.tz)}</div>
                </div>
              </div>
              <div className="text-right leading-tight">
                <div className="font-mono text-[15px] font-bold tabular" style={{ color: st.isOpen ? s.color : '#cbd5e1' }}>
                  {fmtInZone(now, s.tz)}
                </div>
                <div className="font-mono text-[9px] tracking-[0.2em] text-slate-500">{st.isOpen ? 'LIVE' : 'CLOSED'}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
