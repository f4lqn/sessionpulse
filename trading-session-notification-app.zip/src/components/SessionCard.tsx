import { Bell, BellOff } from 'lucide-react';
import {
  dayTag, fmtCountdown, fmtTime, gmtLabel, sessionStateAt, type SessionDef,
} from '../lib/time';
import { Switch } from './ui';
import { cn } from '../utils/cn';
import { useMemo } from 'react';

interface Props {
  sess: SessionDef;
  now: number;
  offsetMin: number;
  notifyOn: boolean;
  onToggleNotify: (v: boolean) => void;
  delay: number;
}

export default function SessionCard({ sess, now, offsetMin, notifyOn, onToggleNotify, delay }: Props) {
  const st = useMemo(() => sessionStateAt(sess, now), [sess, Math.floor(now / 1000)]);
  const open = st.isOpen;

  const target = open ? st.closeUtc : st.nextOpen;
  const remain = target - now;
  const imminent = !open && remain < 15 * 60_000;

  const progress = open
    ? Math.min(1, Math.max(0, (now - st.openUtc) / (st.closeUtc - st.openUtc)))
    : 0;

  return (
    <article
      className={cn(
        'anim-fade-up group relative flex flex-col overflow-hidden rounded-3xl border p-5 transition-all duration-500',
        open
          ? 'live-sheen border-transparent bg-white/[0.045]'
          : 'border-white/[0.07] bg-white/[0.02] hover:border-white/[0.14] hover:bg-white/[0.035]',
      )}
      style={{
        animationDelay: `${delay}ms`,
        boxShadow: open ? `inset 0 0 0 1px ${sess.color}55, 0 8px 40px -18px ${sess.color}55` : undefined,
      }}
    >
      {/* top glow when live */}
      {open && (
        <div className="glow-pulse pointer-events-none absolute -top-16 left-1/2 h-28 w-56 -translate-x-1/2 rounded-full blur-3xl" style={{ background: `${sess.color}30` }} />
      )}

      {/* header */}
      <div className="relative flex items-start justify-between">
        <div className="flex items-center gap-3">
          <span
            className="grid h-11 w-11 place-items-center rounded-2xl font-mono text-[11px] font-extrabold tracking-wider"
            style={{ background: sess.dim, color: sess.color, boxShadow: `inset 0 0 0 1px ${sess.color}40` }}
          >
            {sess.code}
          </span>
          <div className="leading-tight">
            <h3 className="text-[15px] font-bold text-white">{sess.city}</h3>
            <p className="mt-0.5 font-mono text-[9px] tracking-[0.24em] text-slate-500">{sess.region.toUpperCase()} SESSION</p>
          </div>
        </div>

        <span
          className="flex items-center gap-1.5 rounded-full px-2.5 py-1 font-mono text-[9px] font-bold tracking-[0.2em]"
          style={
            open
              ? { background: sess.dim, color: sess.color, boxShadow: `inset 0 0 0 1px ${sess.color}55` }
              : { background: 'rgba(255,255,255,0.05)', color: '#8b95a5', boxShadow: 'inset 0 0 0 1px rgba(255,255,255,0.08)' }
          }
        >
          <span
            className={cn('h-1.5 w-1.5 rounded-full', open && 'ping-dot')}
            style={{ background: open ? sess.color : '#5b6472', ['--pc' as any]: `${sess.color}66` }}
          />
          {open ? 'LIVE' : 'CLOSED'}
        </span>
      </div>

      {/* countdown */}
      <div className="relative mt-6">
        <div className="flex items-center gap-2 font-mono text-[9px] tracking-[0.3em] text-slate-500">
          {open ? 'CLOSES IN' : imminent ? 'RINGING SOON' : 'OPENS IN'}
          {imminent && <span className="rounded bg-amber-400/15 px-1.5 py-0.5 text-[8px] font-bold tracking-[0.15em] text-amber-300">T-15M</span>}
        </div>
        <div
          className="mt-1.5 font-mono text-[34px] font-extrabold leading-none tracking-tight tabular"
          style={{ color: open ? sess.color : imminent ? '#fbbf24' : '#f1f5f9' }}
        >
          {fmtCountdown(remain)}
        </div>
        <div className="mt-2 font-mono text-[11px] tabular text-slate-400">
          {open ? 'until' : 'at'} <span className="font-bold text-slate-200">{fmtTime(target, offsetMin)}</span>
          <span className="text-slate-600"> · {dayTag(target, offsetMin, now)}</span>
        </div>
      </div>

      {/* progress when live */}
      {open && (
        <div className="relative mt-4 h-[3px] overflow-hidden rounded-full bg-white/[0.07]">
          <div
            className="h-full rounded-full transition-[width] duration-1000 ease-linear"
            style={{ width: `${progress * 100}%`, background: `linear-gradient(90deg, ${sess.color}88, ${sess.color})`, boxShadow: `0 0 12px ${sess.color}` }}
          />
        </div>
      )}

      {/* hours */}
      <div className="relative mt-5 grid grid-cols-2 gap-2 border-t border-white/[0.06] pt-4">
        <div>
          <div className="font-mono text-[8px] tracking-[0.28em] text-slate-600">YOUR TIME</div>
          <div className="mt-1 font-mono text-[13px] font-bold tabular text-slate-200">
            {fmtTime(st.openUtc, offsetMin)} – {fmtTime(st.closeUtc, offsetMin)}
          </div>
        </div>
        <div>
          <div className="font-mono text-[8px] tracking-[0.28em] text-slate-600">EXCHANGE LOCAL · {gmtLabel(now, sess.tz)}</div>
          <div className="mt-1 font-mono text-[13px] font-semibold tabular text-slate-400">
            {String(Math.floor(sess.openMin / 60)).padStart(2, '0')}:{String(sess.openMin % 60).padStart(2, '0')} – {String(Math.floor(sess.closeMin / 60)).padStart(2, '0')}:{String(sess.closeMin % 60).padStart(2, '0')}
          </div>
        </div>
      </div>

      {/* notify toggle */}
      <button
        onClick={() => onToggleNotify(!notifyOn)}
        className={cn(
          'relative mt-4 flex items-center justify-between rounded-2xl border px-3.5 py-2.5 transition-all duration-300 active:scale-[0.98]',
          notifyOn ? 'border-transparent' : 'border-white/[0.08] bg-white/[0.03] hover:bg-white/[0.05]',
        )}
        style={notifyOn ? { background: sess.dim, boxShadow: `inset 0 0 0 1px ${sess.color}44` } : undefined}
      >
        <span className="flex items-center gap-2.5">
          {notifyOn
            ? <Bell size={14} style={{ color: sess.color }} />
            : <BellOff size={14} className="text-slate-500" />}
          <span className="text-[12px] font-semibold" style={{ color: notifyOn ? sess.color : '#94a3b8' }}>
            {notifyOn ? 'Opening alert armed' : 'Opening alert off'}
          </span>
        </span>
        <Switch on={notifyOn} onChange={onToggleNotify} accent={sess.color} />
      </button>
    </article>
  );
}
