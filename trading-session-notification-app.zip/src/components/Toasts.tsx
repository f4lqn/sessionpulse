import { X } from 'lucide-react';
import type { FeedItem } from './Console';

interface Props {
  toasts: FeedItem[];
  onDismiss: (id: number) => void;
}

export default function Toasts({ toasts, onDismiss }: Props) {
  return (
    <div className="pointer-events-none fixed bottom-5 right-5 z-[60] flex w-[min(92vw,380px)] flex-col gap-2.5">
      {toasts.map((t) => (
        <div
          key={t.id}
          className="anim-toast pointer-events-auto relative overflow-hidden rounded-2xl border border-white/10 bg-[#0b0f16]/95 p-4 shadow-[0_24px_60px_-16px_rgba(0,0,0,0.9)] backdrop-blur-xl"
          style={{ boxShadow: `0 24px 60px -16px rgba(0,0,0,0.9), inset 3px 0 0 0 ${t.color}` }}
        >
          <div className="pointer-events-none absolute -top-10 -left-10 h-24 w-24 rounded-full blur-2xl" style={{ background: `${t.color}26` }} />
          <div className="relative flex items-start gap-3">
            <span className="ping-dot mt-1.5 h-2 w-2 shrink-0 rounded-full" style={{ background: t.color, ['--pc' as any]: `${t.color}66` }} />
            <div className="min-w-0 flex-1">
              <div className="text-[13px] font-bold text-white">{t.title}</div>
              <p className="mt-0.5 text-[12px] leading-snug text-slate-400">{t.body}</p>
            </div>
            <button
              onClick={() => onDismiss(t.id)}
              className="rounded-md p-1 text-slate-500 transition-colors hover:bg-white/[0.06] hover:text-white"
            >
              <X size={13} />
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
