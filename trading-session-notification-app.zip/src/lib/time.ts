/* ─────────────────────────────────────────────────────────────
   SessionPulse · time engine
   All session maths are computed against exchange-local wall time
   (IANA zones, DST-safe) and rendered in a user-selected fixed
   UTC offset (e.g. UTC+05:30).
──────────────────────────────────────────────────────────────── */

export interface SessionDef {
  id: string;
  code: string;
  city: string;
  name: string;
  region: string;
  tz: string;              // IANA zone of the exchange
  openMin: number;         // minutes after local midnight
  closeMin: number;        // minutes after local midnight (same local day)
  color: string;           // accent hex
  dim: string;             // translucent accent for fills
}

export const SESSIONS: SessionDef[] = [
  {
    id: 'sydney', code: 'SYD', city: 'Sydney', name: 'Sydney Session', region: 'Pacific',
    tz: 'Australia/Sydney', openMin: 8 * 60, closeMin: 17 * 60,
    color: '#F8B35C', dim: 'rgba(248,179,92,0.14)',
  },
  {
    id: 'tokyo', code: 'TYO', city: 'Tokyo', name: 'Tokyo Session', region: 'Asian',
    tz: 'Asia/Tokyo', openMin: 9 * 60, closeMin: 18 * 60,
    color: '#FF5D73', dim: 'rgba(255,93,115,0.14)',
  },
  {
    id: 'london', code: 'LDN', city: 'London', name: 'London Session', region: 'European',
    tz: 'Europe/London', openMin: 8 * 60, closeMin: 16 * 60 + 30,
    color: '#3FE0A8', dim: 'rgba(63,224,168,0.14)',
  },
  {
    id: 'newyork', code: 'NYC', city: 'New York', name: 'New York Session', region: 'N. American',
    tz: 'America/New_York', openMin: 8 * 60, closeMin: 17 * 60,
    color: '#5FB2FF', dim: 'rgba(95,178,255,0.14)',
  },
];

/* ── IANA zone helpers ─────────────────────────────────────── */

const dtfCache = new Map<string, Intl.DateTimeFormat>();
function dtf(tz: string) {
  let f = dtfCache.get(tz);
  if (!f) {
    f = new Intl.DateTimeFormat('en-US', {
      timeZone: tz, hourCycle: 'h23',
      year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit', second: '2-digit',
    });
    dtfCache.set(tz, f);
  }
  return f;
}

export interface ZonedParts { y: number; mo: number; d: number; h: number; mi: number; s: number; }

export function zonedParts(utcMs: number, tz: string): ZonedParts {
  const map: Record<string, string> = {};
  for (const p of dtf(tz).formatToParts(new Date(utcMs))) map[p.type] = p.value;
  let h = +map.hour; if (h === 24) h = 0;
  return { y: +map.year, mo: +map.month - 1, d: +map.day, h, mi: +map.minute, s: +map.second };
}

/** Offset (ms) of an IANA zone at a given UTC instant. */
export function ianaOffsetMs(utcMs: number, tz: string): number {
  const p = zonedParts(utcMs, tz);
  return Date.UTC(p.y, p.mo, p.d, p.h, p.mi, p.s) - Math.floor(utcMs / 1000) * 1000;
}

/** Convert a local wall time in `tz` to an absolute UTC timestamp (DST-safe). */
export function wallToUtcMs(tz: string, y: number, mo: number, d: number, h: number, mi: number): number {
  const guess = Date.UTC(y, mo, d, h, mi);
  let utc = guess - ianaOffsetMs(guess, tz);
  utc = guess - ianaOffsetMs(utc, tz); // refine once for DST transitions
  return utc;
}

function addDaysUTC(y: number, mo: number, d: number, n: number) {
  const t = new Date(Date.UTC(y, mo, d + n));
  return { y: t.getUTCFullYear(), mo: t.getUTCMonth(), d: t.getUTCDate() };
}

function weekdayUTC(y: number, mo: number, d: number) {
  return new Date(Date.UTC(y, mo, d)).getUTCDay(); // 0 Sun … 6 Sat
}
const isWeekend = (y: number, mo: number, d: number) => {
  const w = weekdayUTC(y, mo, d);
  return w === 0 || w === 6;
};

/* ── Session state ─────────────────────────────────────────── */

export interface SessionState {
  isOpen: boolean;
  openUtc: number;   // today's open (or most-recent open if currently open)
  closeUtc: number;  // today's close (when open)
  nextOpen: number;  // next absolute open timestamp
  todayOpenUtc: number | null; // today's open whether passed or not
  todayCloseUtc: number | null;
  localMin: number;  // minutes after exchange-local midnight
}

export function sessionStateAt(sess: SessionDef, utcMs: number): SessionState {
  const p = zonedParts(utcMs, sess.tz);
  const localMin = p.h * 60 + p.mi;
  const weekend = isWeekend(p.y, p.mo, p.d);
  const mk = (y: number, mo: number, d: number, mins: number) =>
    wallToUtcMs(sess.tz, y, mo, d, Math.floor(mins / 60), mins % 60);

  let todayOpenUtc = weekend ? null : mk(p.y, p.mo, p.d, sess.openMin);
  let todayCloseUtc = weekend ? null : mk(p.y, p.mo, p.d, sess.closeMin);
  const isOpen = !weekend && localMin >= sess.openMin && localMin < sess.closeMin;

  // On weekends, surface the next trading day's hours for display.
  if (todayOpenUtc === null) {
    for (let i = 1; i < 8; i++) {
      const dd = addDaysUTC(p.y, p.mo, p.d, i);
      if (isWeekend(dd.y, dd.mo, dd.d)) continue;
      todayOpenUtc = mk(dd.y, dd.mo, dd.d, sess.openMin);
      todayCloseUtc = mk(dd.y, dd.mo, dd.d, sess.closeMin);
      break;
    }
  }

  let nextOpen = Infinity;
  for (let i = 0; i < 8 && nextOpen === Infinity; i++) {
    const dd = addDaysUTC(p.y, p.mo, p.d, i);
    if (isWeekend(dd.y, dd.mo, dd.d)) continue;
    const cand = wallToUtcMs(sess.tz, dd.y, dd.mo, dd.d, Math.floor(sess.openMin / 60), sess.openMin % 60);
    if (cand > utcMs) nextOpen = cand;
  }

  return {
    isOpen,
    openUtc: todayOpenUtc ?? nextOpen,
    closeUtc: todayCloseUtc ?? nextOpen,
    nextOpen,
    todayOpenUtc,
    todayCloseUtc,
    localMin,
  };
}

/* ── Fixed-offset (selected display zone) helpers ──────────── */

export function offsetLabel(offMin: number): string {
  const sign = offMin < 0 ? '−' : '+';
  const a = Math.abs(offMin);
  const h = Math.floor(a / 60);
  const m = a % 60;
  return `UTC${sign}${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

/** Start (UTC ms) of the civil day in a fixed offset zone. */
export function zonedDayStartMs(utcMs: number, offMin: number): number {
  const t = new Date(utcMs + offMin * 60000);
  return Date.UTC(t.getUTCFullYear(), t.getUTCMonth(), t.getUTCDate()) - offMin * 60000;
}

export function minutesIntoZonedDay(utcMs: number, offMin: number): number {
  return (utcMs - zonedDayStartMs(utcMs, offMin)) / 60000;
}

const pad2 = (n: number) => String(n).padStart(2, '0');

export function fmtClock(utcMs: number, offMin: number, withSeconds = true): string {
  const t = new Date(utcMs + offMin * 60000);
  const base = `${pad2(t.getUTCHours())}:${pad2(t.getUTCMinutes())}`;
  return withSeconds ? `${base}:${pad2(t.getUTCSeconds())}` : base;
}

export function fmtTime(utcMs: number, offMin: number): string {
  return fmtClock(utcMs, offMin, false);
}

const DOW = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
const MON = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];

export function fmtDate(utcMs: number, offMin: number): string {
  const t = new Date(utcMs + offMin * 60000);
  return `${DOW[t.getUTCDay()]} · ${pad2(t.getUTCDate())} ${MON[t.getUTCMonth()]} ${t.getUTCFullYear()}`;
}

/** "today / tomorrow / Mon" style relative day tag for a timestamp. */
export function dayTag(utcMs: number, offMin: number, nowMs: number): string {
  const start = zonedDayStartMs(nowMs, offMin);
  const diff = Math.floor((utcMs - start) / 86400000);
  if (diff === 0) return 'today';
  if (diff === 1) return 'tomorrow';
  const t = new Date(utcMs + offMin * 60000);
  return DOW[t.getUTCDay()].toLowerCase();
}

export function fmtCountdown(ms: number): string {
  if (ms < 0) ms = 0;
  const s = Math.floor(ms / 1000);
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  const ss = s % 60;
  if (d > 0) return `${d}d ${pad2(h)}:${pad2(m)}:${pad2(ss)}`;
  return `${pad2(h)}:${pad2(m)}:${pad2(ss)}`;
}

/** Local time readout for one of the financial centres. */
export function fmtInZone(utcMs: number, tz: string, withSeconds = false): string {
  const p = zonedParts(utcMs, tz);
  return `${pad2(p.h)}:${pad2(p.mi)}${withSeconds ? ':' + pad2(p.s) : ''}`;
}

/** GMT offset label of an IANA zone, e.g. "GMT+10" / "GMT+5:30". */
export function gmtLabel(utcMs: number, tz: string): string {
  const off = ianaOffsetMs(utcMs, tz) / 60000;
  const sign = off < 0 ? '−' : '+';
  const a = Math.abs(off);
  const h = Math.floor(a / 60);
  const m = a % 60;
  return `GMT${sign}${h}${m ? ':' + pad2(m) : ''}`;
}

/* ── UTC offset catalogue (incl. :30 / :45 zones) ──────────── */

export interface TzOption { off: number; place: string; }

export const TZ_OPTIONS: TzOption[] = [
  { off: -720, place: 'Baker Island' },
  { off: -660, place: 'Pago Pago' },
  { off: -600, place: 'Honolulu' },
  { off: -570, place: 'Marquesas' },
  { off: -540, place: 'Anchorage' },
  { off: -480, place: 'Los Angeles' },
  { off: -420, place: 'Denver' },
  { off: -360, place: 'Chicago · Mexico City' },
  { off: -300, place: 'New York · Toronto' },
  { off: -240, place: 'Santiago · Halifax' },
  { off: -210, place: 'St. John’s' },
  { off: -180, place: 'São Paulo · Buenos Aires' },
  { off: -120, place: 'South Georgia' },
  { off: -60, place: 'Azores' },
  { off: 0, place: 'London · Reykjavík' },
  { off: 60, place: 'Berlin · Lagos' },
  { off: 120, place: 'Cairo · Johannesburg' },
  { off: 180, place: 'Moscow · Nairobi' },
  { off: 210, place: 'Tehran' },
  { off: 240, place: 'Dubai · Baku' },
  { off: 270, place: 'Kabul' },
  { off: 300, place: 'Karachi · Tashkent' },
  { off: 330, place: 'Mumbai · New Delhi · Colombo' },
  { off: 345, place: 'Kathmandu' },
  { off: 360, place: 'Dhaka · Almaty' },
  { off: 390, place: 'Yangon' },
  { off: 420, place: 'Bangkok · Jakarta' },
  { off: 480, place: 'Singapore · Hong Kong' },
  { off: 525, place: 'Eucla' },
  { off: 540, place: 'Tokyo · Seoul' },
  { off: 570, place: 'Darwin' },
  { off: 600, place: 'Sydney · Brisbane' },
  { off: 630, place: 'Lord Howe Island' },
  { off: 660, place: 'Port Moresby' },
  { off: 720, place: 'Auckland · Suva' },
  { off: 765, place: 'Chatham Islands' },
  { off: 780, place: 'Apia · Nukuʻalofa' },
  { off: 840, place: 'Kiritimati' },
];

export const deviceOffset = () => -new Date().getTimezoneOffset();
