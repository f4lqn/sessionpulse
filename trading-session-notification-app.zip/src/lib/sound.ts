/* Synthesised alert sounds — no assets, pure WebAudio. */

let ctx: AudioContext | null = null;

export function ensureAudio(): AudioContext | null {
  try {
    if (!ctx) ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    if (ctx.state === 'suspended') void ctx.resume();
    return ctx;
  } catch {
    return null;
  }
}

function tone(
  ac: AudioContext,
  freq: number,
  at: number,
  dur: number,
  peak: number,
  type: OscillatorType = 'sine',
) {
  const o = ac.createOscillator();
  const g = ac.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, at);
  g.gain.setValueAtTime(0.0001, at);
  g.gain.exponentialRampToValueAtTime(peak, at + 0.018);
  g.gain.exponentialRampToValueAtTime(0.0001, at + dur);
  o.connect(g).connect(ac.destination);
  o.start(at);
  o.stop(at + dur + 0.05);
}

export type SoundKind = 'chime' | 'pulse' | 'bell';

export function playSound(kind: SoundKind) {
  const ac = ensureAudio();
  if (!ac) return;
  const t = ac.currentTime + 0.02;

  if (kind === 'chime') {
    // two-note glass chime with a soft shimmer
    tone(ac, 987.77, t, 1.1, 0.16);          // B5
    tone(ac, 1975.5, t, 0.5, 0.04);          // harmonic sheen
    tone(ac, 1318.5, t + 0.16, 1.25, 0.18);  // E6
  } else if (kind === 'pulse') {
    // radar ping: quick rising sweep, twice
    for (const dt of [0, 0.22]) {
      const o = ac.createOscillator();
      const g = ac.createGain();
      o.type = 'sine';
      o.frequency.setValueAtTime(660, t + dt);
      o.frequency.exponentialRampToValueAtTime(1320, t + dt + 0.14);
      g.gain.setValueAtTime(0.0001, t + dt);
      g.gain.exponentialRampToValueAtTime(0.2, t + dt + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t + dt + 0.2);
      o.connect(g).connect(ac.destination);
      o.start(t + dt);
      o.stop(t + dt + 0.25);
    }
  } else if (kind === 'bell') {
    // desk bell: triangle strike + inharmonic partials
    tone(ac, 1567.98, t, 1.6, 0.2, 'triangle'); // G6
    tone(ac, 2350.0, t, 0.9, 0.06);
    tone(ac, 3136.0, t, 0.6, 0.035);
  }
}
