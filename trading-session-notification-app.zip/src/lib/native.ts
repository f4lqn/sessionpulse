/* ─────────────────────────────────────────────────────────────
   Native (APK) bridge — Capacitor Local Notifications.

   Why this exists: inside an Android WebView the browser
   `Notification` API is unavailable, and JS timers stall when
   the app is backgrounded. So on native we *schedule* real
   system notifications ahead of time — they fire even when the
   app is fully closed. The schedule is re-synced on every app
   launch, resume, and settings change, covering roughly the next
   two trading weeks (~10 opens per desk).
──────────────────────────────────────────────────────────────── */

import { Capacitor } from '@capacitor/core';
import { LocalNotifications, type LocalNotificationSchema } from '@capacitor/local-notifications';
import { App as CapApp } from '@capacitor/app';
import { SESSIONS, fmtTime, offsetLabel, sessionStateAt } from './time';

export const isNative = Capacitor.isNativePlatform();

export type NativePerm = 'granted' | 'denied' | 'default';

export async function checkNativePerm(): Promise<NativePerm> {
  try {
    const r = await LocalNotifications.checkPermissions();
    return r.display === 'granted' ? 'granted' : r.display === 'denied' ? 'denied' : 'default';
  } catch {
    return 'default';
  }
}

export async function requestNativePerm(): Promise<boolean> {
  try {
    const r = await LocalNotifications.requestPermissions();
    return r.display === 'granted';
  } catch {
    return false;
  }
}

const CHANNEL_ID = 'session-bells';

async function ensureChannel() {
  try {
    await LocalNotifications.createChannel({
      id: CHANNEL_ID,
      name: 'Session bells',
      description: 'Trading session opening alerts',
      importance: 5, // IMPORTANCE_HIGH → heads-up + sound
      visibility: 1,
      vibration: true,
    });
  } catch { /* channel API is Android-only; iOS ignores */ }
}

interface SyncOpts {
  leadMin: number;
  closeAlert: boolean;
  notifyOn: Record<string, boolean>;
  offsetMin: number;
}

export async function syncNativeSchedule(o: SyncOpts): Promise<void> {
  if (!isNative) return;
  if ((await checkNativePerm()) !== 'granted') return;

  await ensureChannel();

  // wipe everything previously scheduled, then rebuild fresh
  const pending = await LocalNotifications.getPending();
  if (pending.notifications.length) {
    await LocalNotifications.cancel({ notifications: pending.notifications });
  }

  const now = Date.now();
  const list: LocalNotificationSchema[] = [];

  SESSIONS.forEach((sess, si) => {
    /* — opening bells: next ~10 opens (about two trading weeks) — */
    if (o.notifyOn[sess.id]) {
      const opens = new Set<number>();
      for (let d = 0; d < 14; d++) opens.add(sessionStateAt(sess, now + d * 86400000).nextOpen);

      [...opens]
        .filter((t) => t > now)
        .sort((a, b) => a - b)
        .slice(0, 10)
        .forEach((openTs, k) => {
          const at = openTs - o.leadMin * 60_000;
          if (at <= now + 2_000) return;
          list.push({
            id: 1000 + si * 100 + k,
            channelId: CHANNEL_ID,
            title: o.leadMin === 0 ? `${sess.city} session is live` : `${sess.city} opens in ${o.leadMin} min`,
            body: `${sess.region} session bell · ${fmtTime(openTs, o.offsetMin)} ${offsetLabel(o.offsetMin)}`,
            schedule: { at: new Date(at), allowWhileIdle: true },
            extra: { session: sess.id, kind: 'open' },
          });
        });
    }

    /* — closing bells: 15 minutes before close, next ~7 trading days — */
    if (o.closeAlert) {
      const closes = new Set<number>();
      for (let d = 0; d < 10; d++) {
        const st = sessionStateAt(sess, now + d * 86400000);
        if (st.todayCloseUtc) closes.add(st.todayCloseUtc);
      }
      [...closes]
        .filter((t) => t > now)
        .sort((a, b) => a - b)
        .slice(0, 7)
        .forEach((closeTs, k) => {
          const at = closeTs - 15 * 60_000;
          if (at <= now + 2_000) return;
          list.push({
            id: 5000 + si * 100 + k,
            channelId: CHANNEL_ID,
            title: `${sess.city} closes in 15 min`,
            body: `${sess.region} desk winds down at ${fmtTime(closeTs, o.offsetMin)} ${offsetLabel(o.offsetMin)}`,
            schedule: { at: new Date(at), allowWhileIdle: true },
            extra: { session: sess.id, kind: 'close' },
          });
        });
    }
  });

  if (list.length) await LocalNotifications.schedule({ notifications: list });
}

/** Show a system notification immediately (used by the test button). */
export async function displayNowNative(title: string, body: string): Promise<void> {
  if (!isNative) return;
  if ((await checkNativePerm()) !== 'granted') return;
  await ensureChannel();
  await LocalNotifications.schedule({
    notifications: [
      {
        id: 9000 + Math.floor(Math.random() * 1000),
        channelId: CHANNEL_ID,
        title,
        body,
        schedule: { at: new Date(Date.now() + 400), allowWhileIdle: true },
      },
    ],
  });
}

/** Run a callback whenever the app returns to the foreground. */
export function onAppResume(cb: () => void): () => void {
  if (!isNative) return () => {};
  const handle = CapApp.addListener('appStateChange', ({ isActive }) => {
    if (isActive) cb();
  });
  return () => {
    void handle.then((h) => h.remove()).catch(() => {});
  };
}
