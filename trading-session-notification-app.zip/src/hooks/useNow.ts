import { useEffect, useState } from 'react';

/** Ticking clock that realigns to the wall-second for crisp countdowns. */
export function useNow(intervalMs = 1000): number {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    let timer: number;
    const tick = () => {
      setNow(Date.now());
      timer = window.setTimeout(tick, intervalMs - (Date.now() % intervalMs) + 8);
    };
    timer = window.setTimeout(tick, intervalMs - (Date.now() % intervalMs) + 8);
    return () => clearTimeout(timer);
  }, [intervalMs]);
  return now;
}
