import { useEffect, useMemo, useRef, useState, useCallback } from 'react';
import Header, { type NotifPerm } from './components/Header';
import MasterClock from './components/MasterClock';
import Timeline from './components/Timeline';
import SessionCard from './components/SessionCard';
import Console, { type FeedItem } from './components/Console';
import Toasts from './components/Toasts';
import { SectionTag } from './components/ui';
import { useNow } from './hooks/useNow';
import { playSound, ensureAudio, type SoundKind } from './lib/sound';
import { SESSIONS, deviceOffset, fmtClock, fmtTime, offsetLabel, sessionStateAt } from './lib/time';
import {
  checkNativePerm, displayNowNative, isNative, onAppResume, requestNativePerm, syncNativeSchedule,
} from './lib/native';

/* ── persisted settings ────────────────────────────────────── */
interface Settings {
  offsetMin: number;
  leadMin: number;
  soundKind: SoundKind;
  soundOn: boolean;
  closeAlert: boolean;
  notifyOn: Record<string, boolean>;
}

const LS_KEY = 'sessionpulse:v1';
const LS_FEED = 'sessionpulse:feed';

function loadSettings(): Settings {
  const fallback: Settings = {
    offsetMin: deviceOffset(),
    leadMin: 5,
    soundKind: 'chime',
    soundOn: true,
    closeAlert: false,
    notifyOn: { sydney: true, tokyo: true, london: true, newyork: true },
  };
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) return fallback;
    const p = JSON.parse(raw);
    return { ...fallback, ...p, notifyOn: { ...fallback.notifyOn, ...(p.notifyOn ?? {}) } };
  } catch {
    return fallback;
  }
}

function loadFeed(): FeedItem[] {
  try {
    const raw = localStorage.getItem(LS_FEED);
    return raw ? (JSON.parse(raw) as FeedItem[]).slice(0, 14) : [];
  } catch {
    return [];
  }
}

export default function App() {
  const now = useNow(1000);

  const [settings, setSettings] = useState<Settings>(loadSettings);
  const [perm, setPerm] = useState<NotifPerm>(() =>
    'Notification' in window ? (Notification.permission as NotifPerm) : 'unsupported',
  );
  const [feed, setFeed] = useState<FeedItem[]>(loadFeed);
  const [toasts, setToasts] = useState<FeedItem[]>([]);
  const idRef = useRef(1);
  const firedRef = useRef<Record<string, number>>({});
  const titleTimerRef = useRef<number | undefined>(undefined);

  const patch = useCallback((p: Partial<Settings>) => {
    setSettings((s) => {
      const next = { ...s, ...p };
      try { localStorage.setItem(LS_KEY, JSON.stringify(next)); } catch { /* noop */ }
      return next;
    });
  }, []);

  useEffect(() => {
    try { localStorage.setItem(LS_FEED, JSON.stringify(feed.slice(0, 14))); } catch { /* noop */ }
  }, [feed]);

  /* ── notification permission (web Notification API vs native APK) ── */
  const refreshPerm = useCallback(async () => {
    if (isNative) {
      setPerm(await checkNativePerm());
      return;
    }
    setPerm('Notification' in window ? (Notification.permission as NotifPerm) : 'unsupported');
  }, []);
  useEffect(() => { void refreshPerm(); }, [refreshPerm]);

  /* ── native APK: keep scheduled session alarms in sync ── */
  const syncSchedule = useCallback(() => {
    void syncNativeSchedule({
      leadMin: settings.leadMin,
      closeAlert: settings.closeAlert,
      notifyOn: settings.notifyOn,
      offsetMin: settings.offsetMin,
    });
  }, [settings]);

  useEffect(() => {
    if (isNative && perm === 'granted') syncSchedule();
  }, [settings, perm, syncSchedule]);

  useEffect(() => onAppResume(() => {
    void refreshPerm().then(() => syncSchedule());
  }), [refreshPerm, syncSchedule]);

  /* ── alert dispatch ───────────────────────────────────────── */
  const fire = useCallback(
    (item: Omit<FeedItem, 'id' | 'ts'>, opts: { toast?: boolean; notify?: boolean; sound?: boolean } = {}) => {
      const { toast = true, notify = true, sound = true } = opts;
      const entry: FeedItem = { ...item, id: idRef.current++, ts: Date.now() };
      setFeed((f) => [entry, ...f].slice(0, 30));
      if (toast) {
        setToasts((t) => [...t, entry].slice(-4));
        window.setTimeout(() => setToasts((t) => t.filter((x) => x.id !== entry.id)), 9000);
      }
      if (sound && settings.soundOn) playSound(settings.soundKind);
      if (notify && !isNative && 'Notification' in window && Notification.permission === 'granted') {
        try {
          new Notification(item.title, { body: item.body, tag: `${item.sessionId ?? 'sp'}-${entry.ts}`, silent: true });
        } catch { /* some platforms require SW — toast already covers us */ }
      }
      // flash tab title briefly
      clearTimeout(titleTimerRef.current);
      document.title = `● ${item.title} · SessionPulse`;
      titleTimerRef.current = window.setTimeout(() => {
        document.title = 'SessionPulse — Global FX Session Alerts';
      }, 12000);
    },
    [settings.soundOn, settings.soundKind],
  );

  /* ── session watch engine ─────────────────────────────────── */
  useEffect(() => {
    for (const sess of SESSIONS) {
      const st = sessionStateAt(sess, now);

      if (settings.notifyOn[sess.id]) {
        const trig = st.nextOpen - settings.leadMin * 60_000;
        const key = `${sess.id}:open`;
        if (now >= trig && now <= st.nextOpen + 30_000 && firedRef.current[key] !== st.nextOpen) {
          firedRef.current[key] = st.nextOpen;
          const atBell = now >= st.nextOpen - 1000;
          fire({
            sessionId: sess.id,
            color: sess.color,
            kind: 'open',
            title: atBell ? `${sess.city} session is live` : `${sess.city} opens in ${settings.leadMin} min`,
            body: atBell
              ? `${sess.region} desk just opened · ${fmtTime(st.nextOpen, settings.offsetMin)} ${offsetLabel(settings.offsetMin)}`
              : `Bell rings at ${fmtTime(st.nextOpen, settings.offsetMin)} ${offsetLabel(settings.offsetMin)}`,
          });
        }
      }

      if (settings.closeAlert && st.isOpen) {
        const trig = st.closeUtc - 15 * 60_000;
        const key = `${sess.id}:close`;
        if (now >= trig && now < st.closeUtc && firedRef.current[key] !== st.closeUtc) {
          firedRef.current[key] = st.closeUtc;
          fire({
            sessionId: sess.id,
            color: '#a78bfa',
            kind: 'close',
            title: `${sess.city} closes in 15 min`,
            body: `${sess.region} desk winds down at ${fmtTime(st.closeUtc, settings.offsetMin)} ${offsetLabel(settings.offsetMin)}`,
          });
        }
      }
    }
  }, [now, settings, fire]);

  /* ── permission request ───────────────────────────────────── */
  const requestPerm = useCallback(async () => {
    if (isNative) {
      const ok = await requestNativePerm();
      setPerm(ok ? 'granted' : 'denied');
      if (ok) {
        fire({
          sessionId: null, color: '#3FE0A8', kind: 'info',
          title: 'Notifications armed',
          body: 'System alarms are scheduled — bells ring even when the app is closed.',
        });
        syncSchedule();
      }
      return;
    }
    if (!('Notification' in window)) { setPerm('unsupported'); return; }
    try {
      const r = await Notification.requestPermission();
      setPerm(r as NotifPerm);
      if (r === 'granted') {
        fire({
          sessionId: null, color: '#3FE0A8', kind: 'info',
          title: 'Notifications armed',
          body: 'You will be pinged the moment a trading session opens.',
        });
      }
    } catch { setPerm('denied'); }
  }, [fire, syncSchedule]);

  /* ── test alert ───────────────────────────────────────────── */
  const testAlert = useCallback(() => {
    ensureAudio();
    const body = `This is exactly how the session bell will feel · ${fmtClock(now, settings.offsetMin)} ${offsetLabel(settings.offsetMin)}`;
    fire(
      { sessionId: null, color: '#22d3ee', kind: 'test', title: 'Test alert fired', body },
      { notify: perm === 'granted' },
    );
    if (isNative && perm === 'granted') void displayNowNative('Test alert fired', body);
  }, [fire, now, settings.offsetMin, perm]);

  const feedWhen = useCallback((ts: number) => fmtClock(ts, settings.offsetMin), [settings.offsetMin]);

  const armedCount = useMemo(() => Object.values(settings.notifyOn).filter(Boolean).length, [settings.notifyOn]);

  return (
    <div className="relative min-h-screen">
      {/* ── backdrop ── */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <img
          src="worldmap.png"
          alt=""
          className="absolute left-1/2 top-[4%] w-[1300px] max-w-none -translate-x-1/2 opacity-[0.17]"
          style={{ maskImage: 'radial-gradient(ellipse 65% 55% at 50% 30%, black 20%, transparent 75%)', WebkitMaskImage: 'radial-gradient(ellipse 65% 55% at 50% 30%, black 20%, transparent 75%)' }}
        />
        <div className="bg-grid absolute inset-0" />
        <div className="absolute -left-40 top-1/3 h-[34rem] w-[34rem] rounded-full bg-cyan-500/[0.05] blur-[130px]" />
        <div className="absolute -right-40 top-[8%] h-[30rem] w-[30rem] rounded-full bg-emerald-500/[0.06] blur-[130px]" />
        <div className="bg-noise absolute inset-0" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_55%,rgba(3,5,8,0.75))]" />
      </div>

      <Header
        perm={perm}
        onRequestPerm={requestPerm}
        offsetMin={settings.offsetMin}
        onOffset={(v) => patch({ offsetMin: v })}
        soundOn={settings.soundOn}
        onSound={(v) => { ensureAudio(); patch({ soundOn: v }); }}
        now={now}
      />

      <main className="relative mx-auto max-w-[1400px] space-y-5 px-4 py-6 sm:px-6 sm:py-9">
        {/* hero status line above clock */}
        <div className="anim-fade-up flex flex-wrap items-center justify-between gap-2 px-1">
          <p className="font-mono text-[10px] tracking-[0.35em] text-slate-500">
            01 — GLOBAL DESK CLOCK
          </p>
          <p className="font-mono text-[10px] tracking-[0.25em] text-slate-600">
            {armedCount}/4 OPENING BELLS ARMED{settings.closeAlert ? ' · CLOSING BELL ON' : ''}
          </p>
        </div>

        <MasterClock now={now} offsetMin={settings.offsetMin} />

        <Timeline now={now} offsetMin={settings.offsetMin} />

        {/* desks */}
        <section>
          <SectionTag
            index="03"
            title="Trading desks"
            right={<span className="font-mono text-[10px] tracking-[0.2em] text-slate-600">MON–FRI · EXCHANGE-LOCAL HOURS</span>}
          />
          <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
            {SESSIONS.map((s, i) => (
              <SessionCard
                key={s.id}
                sess={s}
                now={now}
                offsetMin={settings.offsetMin}
                notifyOn={!!settings.notifyOn[s.id]}
                onToggleNotify={(v) => patch({ notifyOn: { ...settings.notifyOn, [s.id]: v } })}
                delay={250 + i * 70}
              />
            ))}
          </div>
        </section>

        <Console
          leadMin={settings.leadMin}
          onLead={(v) => patch({ leadMin: v })}
          soundKind={settings.soundKind}
          onSoundKind={(v) => { patch({ soundKind: v }); playSound(v); }}
          closeAlert={settings.closeAlert}
          onCloseAlert={(v) => patch({ closeAlert: v })}
          onTest={testAlert}
          feed={feed}
          fmtWhen={feedWhen}
        />

        {/* footer */}
        <footer className="flex flex-col items-center gap-3 border-t border-white/[0.06] pt-8 pb-4 text-center">
          <div className="flex items-center gap-2 font-mono text-[10px] tracking-[0.3em] text-slate-600">
            <span className="h-px w-8 bg-white/10" />
            SESSIONPULSE · FX SESSION RADAR
            <span className="h-px w-8 bg-white/10" />
          </div>
          <p className="max-w-xl text-[12px] leading-relaxed text-slate-500">
            Session hours follow each exchange's local clock and shift automatically with daylight-saving changes
            (Sydney AEDT/AEST, London BST/GMT, New York EDT/EST). Weekends are excluded. Keep this tab open
            and alerts will ring in-app, with sound, and as system notifications.
          </p>
        </footer>
      </main>

      <Toasts toasts={toasts} onDismiss={(id) => setToasts((t) => t.filter((x) => x.id !== id))} />
    </div>
  );
}
